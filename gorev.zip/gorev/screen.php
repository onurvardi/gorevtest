<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$db = new Database();
$conn = $db->getConnection();

// Ekran ID kontrolü
$screen_id = isset($_GET['id']) ? $_GET['id'] : null;
if (!$screen_id || !checkUserPermission($conn, $_SESSION['user_id'], $screen_id)) {
    header("Location: index.php");
    exit;
}

// Ekran bilgilerini getir
$query = "SELECT * FROM screens WHERE id = :id";
$stmt = $conn->prepare($query);
$stmt->execute(['id' => $screen_id]);
$screen = $stmt->fetch(PDO::FETCH_ASSOC);

// Ekranın görevlerini getir
$tasks = getScreenTasks($conn, $screen_id);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $screen['name']; ?> - Ekran Sistemi</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <?php include 'includes/header.php'; ?>

        <div class="screen-dashboard">
            <div class="screen-header">
                <h1><?php echo $screen['name']; ?></h1>
                <div class="screen-filters">
                    <select id="statusFilter">
                        <option value="all">Tüm Durumlar</option>
                        <option value="waiting">Bekleyen</option>
                        <option value="in_progress">Görevde</option>
                        <option value="completed">Tamamlanan</option>
                    </select>
                    <select id="priorityFilter">
                        <option value="all">Tüm Öncelikler</option>
                        <option value="urgent">Acil</option>
                        <option value="normal">Normal</option>
                    </select>
                </div>
            </div>

            <div class="tasks-grid">
                <?php foreach ($tasks as $task): ?>
                <div class="task-card <?php echo $task['priority']; ?> <?php echo $task['status']; ?>">
                    <div class="task-header">
                        <div class="task-status">
                            <?php if ($task['status'] === 'waiting'): ?>
                                <i class="fas fa-clock"></i>
                            <?php elseif ($task['status'] === 'in_progress'): ?>
                                <i class="fas fa-person-walking"></i>
                            <?php else: ?>
                                <i class="fas fa-check-circle"></i>
                            <?php endif; ?>
                            <?php echo formatStatus($task['status']); ?>
                        </div>
                        <span class="task-priority <?php echo $task['priority']; ?>">
                            <?php echo formatPriority($task['priority']); ?>
                        </span>
                    </div>

                    <div class="task-info">
                        <p class="task-location">
                            <i class="fas fa-map-marker-alt"></i>
                            Etap <?php echo $task['etap']; ?> - 
                            <?php echo $task['street_no']; ?> 
                            <?php echo $task['building_name']; ?>/
                            <?php echo $task['apartment_no']; ?>
                        </p>
                        <p class="task-phone">
                            <i class="fas fa-phone"></i>
                            <?php echo $task['phone']; ?>
                        </p>
                        <p class="task-date">
                            <i class="fas fa-calendar"></i>
                            <?php echo formatDate($task['task_date']); ?>
                        </p>
                    </div>

                    <?php if ($task['status'] !== 'completed'): ?>
                    <div class="task-actions">
                        <?php if ($task['status'] === 'waiting'): ?>
                            <button class="btn btn-primary start-task" data-task-id="<?php echo $task['id']; ?>">
                                <i class="fas fa-play"></i> Göreve Başla
                            </button>
                        <?php endif; ?>
                        
                        <?php if ($task['status'] === 'in_progress'): ?>
                            <button class="btn btn-success complete-task" data-task-id="<?php echo $task['id']; ?>">
                                <i class="fas fa-check"></i> Görevi Tamamla
                            </button>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php if ($task['status'] === 'in_progress'): ?>
                    <div class="task-timer">
                        <i class="fas fa-stopwatch"></i>
                        Başlangıç: <?php echo formatDate($task['assigned_at']); ?>
                    </div>
                    <?php endif; ?>

                    <?php if ($task['status'] === 'completed'): ?>
                    <div class="task-completion">
                        <p>
                            <i class="fas fa-check-circle"></i>
                            Tamamlanma: <?php echo formatDate($task['completed_at']); ?>
                        </p>
                        <?php
                        $operations = getTaskOperations($conn, $task['id']);
                        if ($operations): ?>
                            <div class="task-operations">
                                <h4>Yapılan İşlemler:</h4>
                                <?php foreach ($operations as $op): ?>
                                <div class="operation-item">
                                    <span><?php echo $op['operation_description']; ?></span>
                                    <?php if ($op['amount']): ?>
                                        <span class="amount"><?php echo number_format($op['amount'], 2); ?> TL</span>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Görev Tamamlama Modal -->
        <div id="completeTaskModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>Görev Tamamlama</h2>
                <form id="completeTaskForm">
                    <input type="hidden" id="complete_task_id" name="task_id">
                    
                    <div class="form-group">
                        <label for="operation_description">Yapılan İşlem:</label>
                        <textarea id="operation_description" name="operation_description" rows="3"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="amount">Tutar (TL):</label>
                        <input type="number" id="amount" name="amount" step="0.01" min="0">
                    </div>

                    <button type="submit" class="btn btn-success">Görevi Tamamla</button>
                </form>
            </div>
        </div>
    </div>

    <script src="assets/js/screen.js"></script>
</body>
</html>