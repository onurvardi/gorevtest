<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$db = new Database();
$conn = $db->getConnection();

// Kullanıcı yetkisi ve ekran kontrolü
$isAdmin = isAdmin($conn, $_SESSION['user_id']);
$userScreenId = getUserScreenId($conn, $_SESSION['user_id']);

// Bekleyen görevleri getir
$waitingTasks = getWaitingTasks($conn);
$urgentCount = getWaitingTaskCount($conn, 'urgent');
$normalCount = getWaitingTaskCount($conn, 'normal');
$completedCount = getCompletedTaskCount($conn);

include 'includes/header.php';
?>

<div class="container">
    <!-- Özet Kutular -->
    <div class="summary-boxes">
        <div class="box urgent">
            <h3>Acil Bekleyen</h3>
            <span class="count"><?php echo $urgentCount; ?></span>
        </div>
        <div class="box normal">
            <h3>Normal Bekleyen</h3>
            <span class="count"><?php echo $normalCount; ?></span>
        </div>
        <div class="box completed">
            <h3>Tamamlanan</h3>
            <span class="count"><?php echo $completedCount; ?></span>
        </div>
    </div>

    <!-- Görev Listesi -->
    <div class="tasks-container">
        <div class="tasks-header">
            <h2>Bekleyen Görevler</h2>
            <div class="tasks-filter">
                <select id="priorityFilter">
                    <option value="all">Tüm Öncelikler</option>
                    <option value="urgent">Acil</option>
                    <option value="normal">Normal</option>
                </select>
            </div>
        </div>

        <div class="tasks-list">
            <?php foreach ($waitingTasks as $task): ?>
                <div class="task-card <?php echo $task['priority']; ?>">
                    <div class="task-header">
                        <span class="etap">Etap <?php echo $task['etap']; ?></span>
                        <div class="task-badges">
                            <span class="badge <?php echo $task['priority']; ?>">
                                <?php echo formatPriority($task['priority']); ?>
                            </span>
                            <?php if ($task['future_task_date']): ?>
                                <span class="badge future">
                                    İleri Tarihli: <?php echo formatDate($task['future_task_date']); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="task-body">
                        <p><strong>Adres:</strong> <?php echo $task['street_no']; ?> <?php echo $task['building_name']; ?>/<?php echo $task['apartment_no']; ?></p>
                        <p><strong>Telefon:</strong> <?php echo $task['phone']; ?></p>
                        <p><strong>Eklenme:</strong> <?php echo formatDate($task['creation_date']); ?></p>
                    </div>

                    <div class="task-footer">
                        <button class="btn assign-task" data-task-id="<?php echo $task['id']; ?>">
                            Görev Ata
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <?php if (empty($waitingTasks)): ?>
                <div class="no-tasks">
                    <p>Bekleyen görev bulunmuyor.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Görev Ekleme Butonu -->
    <button id="addTaskBtn" class="floating-btn" title="Yeni Görev Ekle">
        <i class="fas fa-plus"></i>
    </button>
</div>

<!-- Görev Ekleme Modal -->
<div id="taskModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Yeni Görev Ekle</h2>
        <form id="taskForm">
            <div class="form-row">
                <div class="form-group">
                    <label for="etap">ETAP Seç:</label>
                    <select name="etap" id="etap" required>
                        <option value="1">1. Etap</option>
                        <option value="2">2. Etap</option>
                        <option value="3">3. Etap</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="street_no">Sokak No:</label>
                    <input type="text" id="street_no" name="street_no" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="building_name">Bina Adı:</label>
                    <input type="text" id="building_name" name="building_name" required>
                </div>
                
                <div class="form-group">
                    <label for="apartment_no">Daire:</label>
                    <input type="text" id="apartment_no" name="apartment_no" required>
                </div>
            </div>

            <div class="form-group">
                <label for="phone">Telefon No:</label>
                <input type="tel" id="phone" name="phone" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="priority">Öncelik:</label>
                    <select name="priority" id="priority" required>
                        <option value="normal">Normal</option>
                        <option value="urgent">Acil</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="future_task_date">İleri Tarihli Görev:</label>
                    <input type="datetime-local" id="future_task_date" name="future_task_date">
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn">Görevi Ekle</button>
            </div>
        </form>
    </div>
</div>

<!-- Görev Atama Modal -->
<div id="assignModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Görev Atama</h2>
        <form id="assignForm">
            <input type="hidden" id="assignTaskId" name="task_id">
            <div class="form-group">
                <label for="screen_id">Ekran Seç:</label>
                <select name="screen_id" id="screen_id" required>
                    <option value="">Ekran Seçin</option>
                    <?php 
                    $screens = getAllScreens($conn);
                    foreach ($screens as $screen):
                        if ($screen['is_active']):
                    ?>
                        <option value="<?php echo $screen['id']; ?>">
                            <?php echo $screen['name']; ?>
                        </option>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </select>
            </div>
            <button type="submit" class="btn">Görevi Ata</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>