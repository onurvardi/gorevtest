<?php
// Görev Sayıları ve Listeleme Fonksiyonları
function getWaitingTaskCount($conn, $priority) {
    $query = "SELECT COUNT(*) as count FROM tasks WHERE status = 'waiting' AND priority = :priority";
    $stmt = $conn->prepare($query);
    $stmt->execute(['priority' => $priority]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['count'];
}

function getCompletedTaskCount($conn) {
    $query = "SELECT COUNT(*) as count FROM tasks WHERE status = 'completed'";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['count'];
}

function getWaitingTasks($conn) {
    $query = "SELECT * FROM tasks 
              WHERE status = 'waiting' 
              ORDER BY 
                CASE 
                    WHEN future_task_date IS NOT NULL AND future_task_date > NOW() 
                    THEN future_task_date 
                    ELSE task_date 
                END ASC, 
                priority DESC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getScreenTasks($conn, $screen_id) {
    $query = "SELECT * FROM tasks WHERE screen_id = :screen_id ORDER BY task_date ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute(['screen_id' => $screen_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Kullanıcı ve Yetki Fonksiyonları
function isAdmin($conn, $user_id) {
    $query = "SELECT role FROM users WHERE id = :user_id";
    $stmt = $conn->prepare($query);
    $stmt->execute(['user_id' => $user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['role'] === 'admin';
}

function getUserScreenId($conn, $user_id) {
    $query = "SELECT id FROM screens WHERE supervisor_id = :user_id";
    $stmt = $conn->prepare($query);
    $stmt->execute(['user_id' => $user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['id'] : null;
}

function getAllScreens($conn) {
    $query = "SELECT s.*, u.full_name as supervisor_name, 
              (SELECT COUNT(*) FROM tasks WHERE screen_id = s.id AND status != 'completed') as active_tasks
              FROM screens s 
              LEFT JOIN users u ON s.supervisor_id = u.id
              WHERE s.id != 1 
              ORDER BY s.name";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getAllUsers($conn) {
    $query = "SELECT * FROM users ORDER BY full_name";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Görev İşleme Fonksiyonları
function addTask($conn, $data) {
    $query = "INSERT INTO tasks (etap, street_no, building_name, apartment_no, phone, 
              task_date, future_task_date, priority, status) 
              VALUES (:etap, :street_no, :building_name, :apartment_no, :phone,
              :task_date, :future_task_date, :priority, 'waiting')";
              
    $task_date = !empty($data['future_task_date']) ? $data['future_task_date'] : date('Y-m-d H:i:s');
    
    $stmt = $conn->prepare($query);
    return $stmt->execute([
        'etap' => $data['etap'],
        'street_no' => $data['street_no'],
        'building_name' => $data['building_name'],
        'apartment_no' => $data['apartment_no'],
        'phone' => $data['phone'],
        'task_date' => $task_date,
        'future_task_date' => !empty($data['future_task_date']) ? $data['future_task_date'] : null,
        'priority' => $data['priority']
    ]);
}

function assignTask($conn, $task_id, $screen_id, $user_id) {
    $query = "UPDATE tasks SET 
              screen_id = :screen_id,
              assigned_by = :assigned_by,
              assigned_at = NOW()
              WHERE id = :task_id";
              
    $stmt = $conn->prepare($query);
    return $stmt->execute([
        'screen_id' => $screen_id,
        'assigned_by' => $user_id,
        'task_id' => $task_id
    ]);
}

function updateTaskStatus($conn, $task_id, $status) {
    $query = "UPDATE tasks SET 
              status = :status,
              completed_at = :completed_at
              WHERE id = :task_id";
              
    $stmt = $conn->prepare($query);
    return $stmt->execute([
        'status' => $status,
        'completed_at' => $status === 'completed' ? date('Y-m-d H:i:s') : null,
        'task_id' => $task_id
    ]);
}

// Format ve Görüntüleme Fonksiyonları
function formatDate($date) {
    return date('d.m.Y H:i', strtotime($date));
}

function formatStatus($status) {
    $statusMap = [
        'waiting' => 'Bekliyor',
        'in_progress' => 'Görevde',
        'completed' => 'Tamamlandı'
    ];
    return $statusMap[$status] ?? $status;
}

function formatPriority($priority) {
    return $priority === 'urgent' ? 'Acil' : 'Normal';
}

// İş Log Fonksiyonları
function addTaskOperation($conn, $task_id, $operation_description, $amount = null) {
    $query = "INSERT INTO task_operations (task_id, operation_description, amount) 
              VALUES (:task_id, :operation_description, :amount)";
    $stmt = $conn->prepare($query);
    return $stmt->execute([
        'task_id' => $task_id,
        'operation_description' => $operation_description,
        'amount' => $amount
    ]);
}

function getTaskOperations($conn, $task_id) {
    $query = "SELECT * FROM task_operations WHERE task_id = :task_id ORDER BY created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->execute(['task_id' => $task_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Güvenlik Fonksiyonları
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function validateDate($date) {
    return (bool)strtotime($date);
}

// İstatistik Fonksiyonları
function getTaskStatistics($conn) {
    $query = "SELECT 
                COUNT(*) as total_tasks,
                SUM(CASE WHEN status = 'waiting' THEN 1 ELSE 0 END) as waiting_tasks,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_tasks,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
                SUM(CASE WHEN priority = 'urgent' THEN 1 ELSE 0 END) as urgent_tasks
              FROM tasks";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>