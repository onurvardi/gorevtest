<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ekran Sistemi</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <header>
        <div class="header-content">
            <h1><?php echo isset($pageTitle) ? $pageTitle : 'Ekran Sistemi'; ?></h1>
            <nav>
                <ul>
                    <li><a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>Ana Ekran</a></li>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <li><a href="admin/" <?php echo strpos($_SERVER['PHP_SELF'], 'admin/') !== false ? 'class="active"' : ''; ?>>Admin Paneli</a></li>
                    <?php endif; ?>
                    <?php if (isset($userScreenId) && $userScreenId): ?>
                        <li><a href="screen.php?id=<?php echo $userScreenId; ?>" <?php echo basename($_SERVER['PHP_SELF']) == 'screen.php' ? 'class="active"' : ''; ?>>Ekranım</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Çıkış</a></li>
                </ul>
            </nav>
        </div>
    </header>