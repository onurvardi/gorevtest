document.addEventListener('DOMContentLoaded', function() {
    // Modal işlemleri için genel fonksiyonlar
    function openModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    // Tüm close butonları için event listener
    document.querySelectorAll('.close').forEach(button => {
        button.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });

    // Modal dışına tıklandığında kapatma
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });

    // Filtreleme işlemleri
    const statusFilter = document.getElementById('statusFilter');
    const priorityFilter = document.getElementById('priorityFilter');
    
    function filterTasks() {
        const status = statusFilter.value;
        const priority = priorityFilter.value;
        
        document.querySelectorAll('.task-card').forEach(card => {
            let showStatus = status === 'all' || card.classList.contains(status);
            let showPriority = priority === 'all' || card.classList.contains(priority);
            
            card.style.display = showStatus && showPriority ? 'flex' : 'none';
        });
    }

    if (statusFilter && priorityFilter) {
        statusFilter.addEventListener('change', filterTasks);
        priorityFilter.addEventListener('change', filterTasks);
    }

    // Görev başlatma işlemi
    document.querySelectorAll('.start-task').forEach(button => {
        button.addEventListener('click', function() {
            const taskId = this.dataset.taskId;
            
            if (confirm('Görevi başlatmak istediğinizden emin misiniz?')) {
                const formData = new FormData();
                formData.append('action', 'start_task');
                formData.append('task_id', taskId);

                fetch('ajax/task_operations.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    showNotification(data.message, data.success ? 'success' : 'error');
                    if (data.success) {
                        setTimeout(() => location.reload(), 1500);
                    }
                })
                .catch(error => {
                    showNotification('Bir hata oluştu', 'error');
                });
            }
        });
    });

    // Görev tamamlama işlemleri
    const completeTaskModal = document.getElementById('completeTaskModal');
    const completeTaskForm = document.getElementById('completeTaskForm');

    document.querySelectorAll('.complete-task').forEach(button => {
        button.addEventListener('click', function() {
            const taskId = this.dataset.taskId;
            document.getElementById('complete_task_id').value = taskId;
            openModal('completeTaskModal');
        });
    });

    if (completeTaskForm) {
        completeTaskForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'complete_task');
            
            fetch('ajax/task_operations.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showNotification(data.message, data.success ? 'success' : 'error');
                if (data.success) {
                    closeModal('completeTaskModal');
                    setTimeout(() => location.reload(), 1500);
                }
            })
            .catch(error => {
                showNotification('Bir hata oluştu', 'error');
            });
        });
    }

    // Görev atama işlemleri
    document.querySelectorAll('.assign-task').forEach(button => {
        button.addEventListener('click', function() {
            const taskId = this.dataset.taskId;
            document.getElementById('assignTaskId').value = taskId;
            openModal('assignModal');
        });
    });

    const assignForm = document.getElementById('assignForm');
    if (assignForm) {
        assignForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'assign_task');
            
            fetch('ajax/task_operations.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showNotification(data.message, data.success ? 'success' : 'error');
                if (data.success) {
                    closeModal('assignModal');
                    setTimeout(() => location.reload(), 1500);
                }
            })
            .catch(error => {
                showNotification('Bir hata oluştu', 'error');
            });
        });
    }

    // Bildirim gösterme fonksiyonu
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animasyon için setTimeout kullanımı
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Otomatik yenileme (opsiyonel)
    let autoRefresh = false;
    const toggleRefreshBtn = document.getElementById('toggleRefresh');
    let refreshInterval;

    if (toggleRefreshBtn) {
        toggleRefreshBtn.addEventListener('click', function() {
            autoRefresh = !autoRefresh;
            this.textContent = autoRefresh ? 'Otomatik Yenileme Kapat' : 'Otomatik Yenileme Aç';
            
            if (autoRefresh) {
                refreshInterval = setInterval(() => {
                    location.reload();
                }, 60000); // 1 dakika
            } else {
                clearInterval(refreshInterval);
            }
        });
    }

    // Tutar alanı için para formatı
    const amountInput = document.getElementById('amount');
    if (amountInput) {
        amountInput.addEventListener('input', function(e) {
            let value = this.value.replace(/[^0-9.]/g, '');
            if (value.split('.').length > 2) {
                const parts = value.split('.');
                value = parts[0] + '.' + parts.slice(1).join('');
            }
            this.value = value;
        });
    }
});