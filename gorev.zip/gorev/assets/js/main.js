document.addEventListener('DOMContentLoaded', function() {
    // Modal işlemleri için genel fonksiyonlar
    function openModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    // Tüm close butonları için event listener
    document.querySelectorAll('.close').forEach(button => {
        button.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });

    // Modal dışına tıklandığında kapatma
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });

    // Görev ekleme butonu ve modal işlemleri
    const addTaskBtn = document.getElementById('addTaskBtn');
    if (addTaskBtn) {
        addTaskBtn.addEventListener('click', function() {
            openModal('taskModal');
        });
    }

    // Görev formu gönderimi
    const taskForm = document.getElementById('taskForm');
    if (taskForm) {
        taskForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'add_task');
            
            fetch('ajax/task_operations.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showNotification(data.message, data.success ? 'success' : 'error');
                if (data.success) {
                    closeModal('taskModal');
                    taskForm.reset();
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                }
            })
            .catch(error => {
                showNotification('Bir hata oluştu', 'error');
                console.error('Error:', error);
            });
        });
    }

    // Görev atama butonları
    document.querySelectorAll('.assign-task').forEach(button => {
        button.addEventListener('click', function() {
            const taskId = this.dataset.taskId;
            document.getElementById('assignTaskId').value = taskId;
            openModal('assignModal');
        });
    });

    // Görev atama formu gönderimi
    const assignForm = document.getElementById('assignForm');
    if (assignForm) {
        assignForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'assign_task');
            
            fetch('ajax/task_operations.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showNotification(data.message, data.success ? 'success' : 'error');
                if (data.success) {
                    closeModal('assignModal');
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                }
            })
            .catch(error => {
                showNotification('Bir hata oluştu', 'error');
                console.error('Error:', error);
            });
        });
    }

    // Filtreleme işlemleri
    const priorityFilter = document.getElementById('priorityFilter');
    if (priorityFilter) {
        priorityFilter.addEventListener('change', function() {
            const value = this.value;
            const cards = document.querySelectorAll('.task-card');
            
            cards.forEach(card => {
                if (value === 'all' || card.classList.contains(value)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }

    // Tarih alanı için minimum değer ayarlama
    const futureTaskDate = document.getElementById('future_task_date');
    if (futureTaskDate) {
        // Minimum tarih olarak bugünü ayarla
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        futureTaskDate.min = now.toISOString().slice(0, 16);
    }

    // Bildirim gösterme fonksiyonu
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animasyon için setTimeout kullanımı
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Telefon numarası formatı
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = this.value.replace(/\D/g, '');
            if (value.length > 10) {
                value = value.substr(0, 10);
            }
            this.value = value.replace(/(\d{3})(\d{3})(\d{4})/, '$1 $2 $3').trim();
        });
    }
});