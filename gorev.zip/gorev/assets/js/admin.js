document.addEventListener('DOMContentLoaded', function() {
    // Modal işlemleri için genel fonksiyonlar
    function openModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    // Tüm close butonları için event listener
    document.querySelectorAll('.close, .close-modal').forEach(button => {
        button.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });

    // Modal dışına tıklandığında kapatma
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });

    // Ekran ekleme/düzenleme işlemleri
    const addScreenBtn = document.getElementById('addScreenBtn');
    if (addScreenBtn) {
        addScreenBtn.onclick = function() {
            document.getElementById('screenForm').reset();
            document.getElementById('screen_id').value = '';
            openModal('screenModal');
        }
    }

    // Ekran düzenleme butonları
    document.querySelectorAll('.edit-screen').forEach(button => {
        button.addEventListener('click', function() {
            const screenId = this.dataset.id;
            
            fetch('ajax/get_screen.php?id=' + screenId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const form = document.getElementById('screenForm');
                        form.screen_id.value = data.screen.id;
                        form.name.value = data.screen.name;
                        form.description.value = data.screen.description;
                        form.supervisor_id.value = data.screen.supervisor_id;
                        form.is_active.checked = data.screen.is_active === '1';
                        
                        openModal('screenModal');
                    } else {
                        showNotification(data.message, 'error');
                    }
                })
                .catch(error => {
                    showNotification('Bir hata oluştu', 'error');
                });
        });
    });

    // Ekran formunu gönderme
    const screenForm = document.getElementById('screenForm');
    if (screenForm) {
        screenForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('ajax/save_screen.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showNotification(data.message, data.success ? 'success' : 'error');
                if (data.success) {
                    closeModal('screenModal');
                    setTimeout(() => location.reload(), 1500);
                }
            })
            .catch(error => {
                showNotification('Bir hata oluştu', 'error');
            });
        });
    }

    // Kullanıcı ekleme/düzenleme işlemleri
    const addUserBtn = document.getElementById('addUserBtn');
    if (addUserBtn) {
        addUserBtn.onclick = function() {
            document.getElementById('userForm').reset();
            document.getElementById('user_id').value = '';
            document.querySelector('.new-user-only').style.display = 'block';
            openModal('userModal');
        }
    }

    // Kullanıcı rol değişikliği kontrolü
    const roleSelect = document.getElementById('role');
    if (roleSelect) {
        roleSelect.addEventListener('change', function() {
            const supervisorSection = document.querySelector('.supervisor-section');
            if (this.value === 'supervisor') {
                supervisorSection.style.display = 'block';
            } else {
                supervisorSection.style.display = 'none';
            }
        });
    }

    // Ekran durumu değiştirme
    document.querySelectorAll('.toggle-screen').forEach(button => {
        button.addEventListener('click', function() {
            const screenId = this.dataset.id;
            const currentStatus = this.dataset.status === '1';
            
            fetch('ajax/toggle_screen_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    screen_id: screenId,
                    status: !currentStatus
                })
            })
            .then(response => response.json())
            .then(data => {
                showNotification(data.message, data.success ? 'success' : 'error');
                if (data.success) {
                    setTimeout(() => location.reload(), 1500);
                }
            })
            .catch(error => {
                showNotification('Bir hata oluştu', 'error');
            });
        });
    });

    // Sistem ayarları işlemleri
    const backupDbBtn = document.getElementById('backupDb');
    if (backupDbBtn) {
        backupDbBtn.addEventListener('click', function() {
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Yedekleniyor...';
            
            fetch('ajax/backup_database.php')
                .then(response => response.json())
                .then(data => {
                    showNotification(data.message, data.success ? 'success' : 'error');
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-download"></i> Veritabanı Yedeği Al';
                })
                .catch(error => {
                    showNotification('Bir hata oluştu', 'error');
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-download"></i> Veritabanı Yedeği Al';
                });
        });
    }

    // Bildirim gösterme fonksiyonu
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
});