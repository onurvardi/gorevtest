<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'Oturum açmanız gerekiyor']));
}

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $task_id = $_POST['task_id'] ?? null;

    // Görev başlatma
    if ($action === 'start_task') {
        try {
            $stmt = $conn->prepare("UPDATE tasks SET status = 'in_progress' WHERE id = :task_id");
            $result = $stmt->execute(['task_id' => $task_id]);
            
            echo json_encode([
                'success' => $result,
                'message' => $result ? 'Görev başlatıldı' : 'Görev başlatılamadı'
            ]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Veritabanı hatası']);
        }
    }
    
    // Görev tamamlama
    elseif ($action === 'complete_task') {
        try {
            $conn->beginTransaction();

            // Görevi tamamlandı olarak işaretle
            $stmt = $conn->prepare("UPDATE tasks SET 
                status = 'completed', 
                completed_at = NOW() 
                WHERE id = :task_id");
            $result = $stmt->execute(['task_id' => $task_id]);

            // İşlem kaydı ekle
            if (!empty($_POST['operation_description'])) {
                $stmt = $conn->prepare("INSERT INTO task_operations 
                    (task_id, operation_description, amount) 
                    VALUES (:task_id, :description, :amount)");
                $stmt->execute([
                    'task_id' => $task_id,
                    'description' => $_POST['operation_description'],
                    'amount' => $_POST['amount'] ?? null
                ]);
            }

            $conn->commit();
            echo json_encode([
                'success' => true,
                'message' => 'Görev başarıyla tamamlandı'
            ]);
        } catch (PDOException $e) {
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => 'Veritabanı hatası']);
        }
    }
    
    // Görev atama
    elseif ($action === 'assign_task') {
        try {
            $screen_id = $_POST['screen_id'] ?? null;
            
            $stmt = $conn->prepare("UPDATE tasks SET 
                screen_id = :screen_id,
                assigned_by = :assigned_by,
                assigned_at = NOW() 
                WHERE id = :task_id");
            
            $result = $stmt->execute([
                'screen_id' => $screen_id,
                'assigned_by' => $_SESSION['user_id'],
                'task_id' => $task_id
            ]);

            echo json_encode([
                'success' => $result,
                'message' => $result ? 'Görev atandı' : 'Görev atanamadı'
            ]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Veritabanı hatası']);
        }
    }
}
?>