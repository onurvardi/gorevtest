<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['user_id']) || !isAdmin($conn, $_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$db = new Database();
$conn = $db->getConnection();

// Tüm kullanıcıları getir
$query = "SELECT u.*, s.name as screen_name 
          FROM users u 
          LEFT JOIN screens s ON s.supervisor_id = u.id 
          ORDER BY u.full_name";
$stmt = $conn->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Tüm ekranları getir
$screens = getAllScreens($conn);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Yönetimi - Admin Paneli</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-container">
        <!-- Admin Sidebar -->
        <div class="admin-sidebar">
            <?php include 'includes/sidebar.php'; ?>
        </div>

        <div class="admin-content">
            <header class="admin-header">
                <h1>Kullanıcı Yönetimi</h1>
                <button id="addUserBtn" class="btn">
                    <i class="fas fa-user-plus"></i> Yeni Kullanıcı
                </button>
            </header>

            <div class="users-grid">
                <?php foreach ($users as $user): ?>
                <div class="user-card">
                    <div class="user-header">
                        <h3><?php echo $user['full_name']; ?></h3>
                        <span class="role-badge <?php echo $user['role']; ?>">
                            <?php echo ucfirst($user['role']); ?>
                        </span>
                    </div>

                    <div class="user-info">
                        <p><i class="fas fa-user"></i> <?php echo $user['username']; ?></p>
                        <?php if ($user['screen_name']): ?>
                            <p><i class="fas fa-desktop"></i> <?php echo $user['screen_name']; ?></p>
                        <?php endif; ?>
                        <p><i class="fas fa-calendar"></i> <?php echo formatDate($user['created_at']); ?></p>
                    </div>

                    <div class="user-actions">
                        <button class="btn btn-sm edit-user" data-id="<?php echo $user['id']; ?>">
                            <i class="fas fa-edit"></i> Düzenle
                        </button>
                        <button class="btn btn-sm reset-password" data-id="<?php echo $user['id']; ?>">
                            <i class="fas fa-key"></i> Şifre Sıfırla
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Kullanıcı Ekleme/Düzenleme Modal -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Kullanıcı Ekle/Düzenle</h2>
            <form id="userForm">
                <input type="hidden" name="user_id" id="user_id">
                
                <div class="form-group">
                    <label for="full_name">Ad Soyad:</label>
                    <input type="text" id="full_name" name="full_name" required>
                </div>

                <div class="form-group">
                    <label for="username">Kullanıcı Adı:</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="role">Rol:</label>
                    <select id="role" name="role" required>
                        <option value="user">Kullanıcı</option>
                        <option value="supervisor">Ekran Sorumlusu</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>

                <div class="form-group supervisor-section" style="display: none;">
                    <label for="screen_id">Sorumlu Olduğu Ekran:</label>
                    <select id="screen_id" name="screen_id">
                        <option value="">Ekran Seçin</option>
                        <?php foreach ($screens as $screen): ?>
                            <option value="<?php echo $screen['id']; ?>">
                                <?php echo $screen['name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group new-user-only">
                    <label for="password">Şifre:</label>
                    <input type="password" id="password" name="password">
                </div>

                <button type="submit" class="btn">Kaydet</button>
            </form>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>