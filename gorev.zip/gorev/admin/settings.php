<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['user_id']) || !isAdmin($conn, $_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$db = new Database();
$conn = $db->getConnection();

// Sistem istatistikleri
$stats = getTaskStatistics($conn);

// Veritabanı yedeği alma fonksiyonu
function backupDatabase($conn) {
    // Bu fonksiyon daha sonra implement edilecek
    return true;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Ayarları - Admin Paneli</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-container">
        <!-- Admin Sidebar -->
        <div class="admin-sidebar">
            <?php include 'includes/sidebar.php'; ?>
        </div>

        <div class="admin-content">
            <header class="admin-header">
                <h1>Sistem Ayarları</h1>
            </header>

            <div class="settings-grid">
                <!-- Sistem Bilgileri -->
                <div class="settings-card">
                    <div class="settings-header">
                        <h3><i class="fas fa-info-circle"></i> Sistem Bilgileri</h3>
                    </div>
                    <div class="settings-body">
                        <div class="info-row">
                            <span class="info-label">PHP Versiyonu:</span>
                            <span class="info-value"><?php echo phpversion(); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">MySQL Versiyonu:</span>
                            <span class="info-value"><?php echo $conn->getAttribute(PDO::ATTR_SERVER_VERSION); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Toplam Görev:</span>
                            <span class="info-value"><?php echo $stats['total_tasks']; ?></span>
                        </div>
                    </div>
                </div>

                <!-- Veritabanı Yedekleme -->
                <div class="settings-card">
                    <div class="settings-header">
                        <h3><i class="fas fa-database"></i> Veritabanı Yönetimi</h3>
                    </div>
                    <div class="settings-body">
                        <button id="backupDb" class="btn">
                            <i class="fas fa-download"></i> Veritabanı Yedeği Al
                        </button>
                    </div>
                </div>

                <!-- Sistem Temizleme -->
                <div class="settings-card">
                    <div class="settings-header">
                        <h3><i class="fas fa-broom"></i> Sistem Temizleme</h3>
                    </div>
                    <div class="settings-body">
                        <button id="clearOldTasks" class="btn btn-warning">
                            <i class="fas fa-trash"></i> Eski Görevleri Temizle
                        </button>
                        <p class="settings-note">
                            * 6 aydan eski tamamlanmış görevleri temizler.
                        </p>
                    </div>
                </div>

                <!-- Güvenlik Ayarları -->
                <div class="settings-card">
                    <div class="settings-header">
                        <h3><i class="fas fa-shield-alt"></i> Güvenlik Ayarları</h3>
                    </div>
                    <div class="settings-body">
                        <form id="securitySettingsForm">
                            <div class="form-group">
                                <label for="session_timeout">Oturum Zaman Aşımı (dakika):</label>
                                <input type="number" id="session_timeout" name="session_timeout" value="30">
                            </div>
                            <button type="submit" class="btn">Kaydet</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>