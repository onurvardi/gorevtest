<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || !isAdmin($conn, $_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'Yetkisiz erişim']));
}

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'save_screen':
            try {
                $screen_id = $_POST['screen_id'] ?? null;
                $is_active = isset($_POST['is_active']) ? 1 : 0;
                
                if ($screen_id) {
                    // Ekran güncelleme
                    $query = "UPDATE screens SET 
                             name = :name,
                             description = :description,
                             supervisor_id = :supervisor_id,
                             is_active = :is_active
                             WHERE id = :id";
                    
                    $stmt = $conn->prepare($query);
                    $result = $stmt->execute([
                        'name' => $_POST['name'],
                        'description' => $_POST['description'],
                        'supervisor_id' => $_POST['supervisor_id'] ?: null,
                        'is_active' => $is_active,
                        'id' => $screen_id
                    ]);
                } else {
                    // Yeni ekran ekleme
                    $query = "INSERT INTO screens (name, description, supervisor_id, is_active) 
                             VALUES (:name, :description, :supervisor_id, :is_active)";
                    
                    $stmt = $conn->prepare($query);
                    $result = $stmt->execute([
                        'name' => $_POST['name'],
                        'description' => $_POST['description'],
                        'supervisor_id' => $_POST['supervisor_id'] ?: null,
                        'is_active' => $is_active
                    ]);
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => $screen_id ? 'Ekran güncellendi' : 'Ekran eklendi'
                ]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Veritabanı hatası']);
            }
            break;

        case 'toggle_screen':
            try {
                $screen_id = $_POST['screen_id'] ?? null;
                $status = $_POST['status'] ?? null;
                
                if ($screen_id !== null && $status !== null) {
                    $query = "UPDATE screens SET is_active = :status WHERE id = :id";
                    $stmt = $conn->prepare($query);
                    $result = $stmt->execute([
                        'status' => $status,
                        'id' => $screen_id
                    ]);
                    
                    echo json_encode([
                        'success' => true,
                        'message' => 'Ekran durumu güncellendi'
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Geçersiz parametre'
                    ]);
                }
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Veritabanı hatası']);
            }
            break;

        case 'save_user':
            try {
                $user_id = $_POST['user_id'] ?? null;
                
                if ($user_id) {
                    // Kullanıcı güncelleme
                    $query = "UPDATE users SET 
                             full_name = :full_name,
                             username = :username,
                             role = :role
                             WHERE id = :id";
                    
                    $stmt = $conn->prepare($query);
                    $result = $stmt->execute([
                        'full_name' => $_POST['full_name'],
                        'username' => $_POST['username'],
                        'role' => $_POST['role'],
                        'id' => $user_id
                    ]);

                    // Eğer şifre değiştirilecekse
                    if (!empty($_POST['password'])) {
                        $query = "UPDATE users SET password = :password WHERE id = :id";
                        $stmt = $conn->prepare($query);
                        $stmt->execute([
                            'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                            'id' => $user_id
                        ]);
                    }
                } else {
                    // Yeni kullanıcı ekleme
                    $query = "INSERT INTO users (full_name, username, password, role) 
                             VALUES (:full_name, :username, :password, :role)";
                    
                    $stmt = $conn->prepare($query);
                    $result = $stmt->execute([
                        'full_name' => $_POST['full_name'],
                        'username' => $_POST['username'],
                        'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                        'role' => $_POST['role']
                    ]);
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => $user_id ? 'Kullanıcı güncellendi' : 'Kullanıcı eklendi'
                ]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Veritabanı hatası']);
            }
            break;

        case 'backup_database':
            try {
                // Veritabanı yedekleme işlemi burada gerçekleştirilecek
                echo json_encode([
                    'success' => true,
                    'message' => 'Veritabanı yedeği alındı'
                ]);
            } catch (Exception $e) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Yedekleme işlemi başarısız'
                ]);
            }
            break;

        default:
            echo json_encode([
                'success' => false,
                'message' => 'Geçersiz işlem'
            ]);
            break;
    }
}
?>