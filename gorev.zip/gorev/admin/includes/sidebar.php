<div class="sidebar-header">
    <h2>Admin Paneli</h2>
</div>
<nav class="sidebar-nav">
    <ul>
        <li <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
            <a href="index.php">
                <i class="fas fa-home"></i>
                <span>Ana Sayfa</span>
            </a>
        </li>
        <li <?php echo basename($_SERVER['PHP_SELF']) == 'screens.php' ? 'class="active"' : ''; ?>>
            <a href="screens.php">
                <i class="fas fa-desktop"></i>
                <span>Ekranlar</span>
            </a>
        </li>
        <li <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
            <a href="users.php">
                <i class="fas fa-users"></i>
                <span>Kullanıcılar</span>
            </a>
        </li>
        <li <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'class="active"' : ''; ?>>
            <a href="settings.php">
                <i class="fas fa-cog"></i>
                <span>Ayarlar</span>
            </a>
        </li>
        <li>
            <a href="../index.php">
                <i class="fas fa-arrow-left"></i>
                <span>Ana Ekrana Dön</span>
            </a>
        </li>
    </ul>
</nav>