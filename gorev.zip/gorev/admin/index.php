<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['user_id']) || !isAdmin($conn, $_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$db = new Database();
$conn = $db->getConnection();

// İstatistikleri getir
$stats = getTaskStatistics($conn);
$screens = getAllScreens($conn);

// Son aktiviteleri getir
$query = "SELECT t.*, s.name as screen_name, u.full_name as user_name 
          FROM tasks t 
          LEFT JOIN screens s ON t.screen_id = s.id 
          LEFT JOIN users u ON t.assigned_by = u.id 
          ORDER BY t.creation_date DESC LIMIT 10";
$stmt = $conn->prepare($query);
$stmt->execute();
$recent_tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli - Ekran Sistemi</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-container">
        <!-- Admin Sidebar -->
        <div class="admin-sidebar">
            <div class="sidebar-header">
                <h2>Admin Paneli</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li class="active">
                        <a href="index.php">
                            <i class="fas fa-home"></i>
                            <span>Ana Sayfa</span>
                        </a>
                    </li>
                    <li>
                        <a href="screens.php">
                            <i class="fas fa-desktop"></i>
                            <span>Ekranlar</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php">
                            <i class="fas fa-users"></i>
                            <span>Kullanıcılar</span>
                        </a>
                    </li>
                    <li>
                        <a href="settings.php">
                            <i class="fas fa-cog"></i>
                            <span>Ayarlar</span>
                        </a>
                    </li>
                    <li>
                        <a href="../index.php">
                            <i class="fas fa-arrow-left"></i>
                            <span>Ana Ekrana Dön</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- Admin Content -->
        <div class="admin-content">
            <header class="admin-header">
                <h1>Yönetim Paneli</h1>
                <div class="admin-user">
                    <span><?php echo $_SESSION['full_name']; ?></span>
                    <a href="../logout.php" class="btn btn-sm">Çıkış</a>
                </div>
            </header>

            <!-- İstatistik Kartları -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Toplam Görev</h3>
                        <span class="stat-value"><?php echo $stats['total_tasks']; ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon urgent">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Acil Görevler</h3>
                        <span class="stat-value"><?php echo $stats['urgent_tasks']; ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon waiting">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Bekleyen</h3>
                        <span class="stat-value"><?php echo $stats['waiting_tasks']; ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon success">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Tamamlanan</h3>
                        <span class="stat-value"><?php echo $stats['completed_tasks']; ?></span>
                    </div>
                </div>
            </div>

            <!-- Ekran Durumları -->
            <div class="screens-overview">
                <div class="section-header">
                    <h2>Ekran Durumları</h2>
                    <a href="screens.php" class="btn btn-sm">
                        <i class="fas fa-external-link-alt"></i> Tümünü Görüntüle
                    </a>
                </div>
                <div class="screen-grid">
                    <?php foreach ($screens as $screen): ?>
                    <div class="screen-card">
                        <div class="screen-header">
                            <h3><?php echo $screen['name']; ?></h3>
                            <span class="status-badge <?php echo $screen['is_active'] ? 'active' : 'inactive'; ?>">
                                <?php echo $screen['is_active'] ? 'Aktif' : 'Pasif'; ?>
                            </span>
                        </div>
                        <div class="screen-info">
                            <div class="info-row">
                                <span class="info-label"><i class="fas fa-user"></i> Sorumlu:</span>
                                <span class="info-value"><?php echo $screen['supervisor_name'] ?? 'Atanmamış'; ?></span>
                            </div>
                            <div class="info-row">
                                <span class="info-label"><i class="fas fa-tasks"></i> Aktif Görev:</span>
                                <span class="info-value"><?php echo $screen['active_tasks']; ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Son Aktiviteler -->
            <div class="recent-activities">
                <div class="section-header">
                    <h2>Son İşlemler</h2>
                </div>
                <div class="activity-list">
                    <?php foreach ($recent_tasks as $task): ?>
                    <div class="activity-item">
                        <div class="activity-icon">
                            <?php if ($task['status'] === 'completed'): ?>
                                <i class="fas fa-check-circle text-success"></i>
                            <?php elseif ($task['status'] === 'in_progress'): ?>
                                <i class="fas fa-clock text-warning"></i>
                            <?php else: ?>
                                <i class="fas fa-plus-circle text-primary"></i>
                            <?php endif; ?>
                        </div>
                        <div class="activity-details">
                            <div class="activity-header">
                                <strong class="activity-title">
                                    <?php echo formatStatus($task['status']); ?>
                                </strong>
                                <?php if ($task['screen_name']): ?>
                                    <span class="screen-name"><?php echo $task['screen_name']; ?></span>
                                <?php endif; ?>
                                <span class="priority-badge <?php echo $task['priority']; ?>">
                                    <?php echo formatPriority($task['priority']); ?>
                                </span>
                            </div>
                            <p class="activity-info">
                                Etap <?php echo $task['etap']; ?> - 
                                <?php echo $task['street_no']; ?> 
                                <?php echo $task['building_name']; ?>/
                                <?php echo $task['apartment_no']; ?>
                            </p>
                            <div class="activity-meta">
                                <span class="activity-time">
                                    <i class="far fa-clock"></i>
                                    <?php echo formatDate($task['creation_date']); ?>
                                </span>
                                <?php if ($task['user_name']): ?>
                                    <span class="activity-user">
                                        <i class="far fa-user"></i>
                                        <?php echo $task['user_name']; ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>