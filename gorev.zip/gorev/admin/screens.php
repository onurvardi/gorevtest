<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['user_id']) || !isAdmin($conn, $_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$db = new Database();
$conn = $db->getConnection();

$screens = getAllScreens($conn);
$users = getAllUsers($conn);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ekran Yönetimi - Admin Paneli</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="admin-container">
        <!-- Admin Sidebar -->
        <div class="admin-sidebar">
            <?php include 'includes/sidebar.php'; ?>
        </div>

        <!-- Ana İçerik -->
        <div class="admin-content">
            <header class="admin-header">
                <h1>Ekran Yönetimi</h1>
                <button id="addScreenBtn" class="btn">
                    <i class="fas fa-plus"></i> Yeni Ekran
                </button>
            </header>

            <!-- Ekran Listesi -->
            <div class="screens-grid">
                <?php foreach ($screens as $screen): ?>
                <div class="screen-card">
                    <div class="screen-header">
                        <h3><?php echo $screen['name']; ?></h3>
                        <div class="screen-badges">
                            <span class="status-badge <?php echo $screen['is_active'] ? 'active' : 'inactive'; ?>">
                                <?php echo $screen['is_active'] ? 'Aktif' : 'Pasif'; ?>
                            </span>
                            <span class="task-badge">
                                <i class="fas fa-tasks"></i> <?php echo $screen['active_tasks']; ?> Görev
                            </span>
                        </div>
                    </div>

                    <div class="screen-body">
                        <div class="screen-description">
                            <?php echo $screen['description'] ?? 'Açıklama bulunmuyor.'; ?>
                        </div>
                        
                        <div class="screen-info">
                            <div class="info-row">
                                <span class="info-label">
                                    <i class="fas fa-user"></i> Sorumlu:
                                </span>
                                <span class="info-value">
                                    <?php echo $screen['supervisor_name'] ?? 'Atanmamış'; ?>
                                </span>
                            </div>
                            <div class="info-row">
                                <span class="info-label">
                                    <i class="fas fa-calendar"></i> Oluşturulma:
                                </span>
                                <span class="info-value">
                                    <?php echo formatDate($screen['created_at']); ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="screen-actions">
                        <button class="btn btn-sm edit-screen" data-id="<?php echo $screen['id']; ?>">
                            <i class="fas fa-edit"></i> Düzenle
                        </button>
                        <button class="btn btn-sm toggle-screen" data-id="<?php echo $screen['id']; ?>" 
                                data-status="<?php echo $screen['is_active']; ?>">
                            <i class="fas fa-power-off"></i>
                            <?php echo $screen['is_active'] ? 'Pasif Yap' : 'Aktif Yap'; ?>
                        </button>
                        <a href="screen_tasks.php?id=<?php echo $screen['id']; ?>" class="btn btn-sm">
                            <i class="fas fa-tasks"></i> Görevleri Görüntüle
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Ekran Ekleme/Düzenleme Modal -->
    <div id="screenModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Ekran Ekle/Düzenle</h2>
            <form id="screenForm">
                <input type="hidden" name="action" value="save_screen">
                <input type="hidden" name="screen_id" id="screen_id">
                
                <div class="form-group">
                    <label for="screen_name">Ekran Adı:</label>
                    <input type="text" id="screen_name" name="name" required>
                </div>

                <div class="form-group">
                    <label for="screen_description">Açıklama:</label>
                    <textarea id="screen_description" name="description" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label for="supervisor_id">Sorumlu:</label>
                    <select id="supervisor_id" name="supervisor_id">
                        <option value="">Sorumlu Seçin</option>
                        <?php foreach ($users as $user): ?>
                            <?php if ($user['role'] === 'supervisor'): ?>
                                <option value="<?php echo $user['id']; ?>">
                                    <?php echo $user['full_name']; ?>
                                </option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="is_active" name="is_active" value="1" checked>
                        Ekran Aktif
                    </label>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn">Kaydet</button>
                    <button type="button" class="btn btn-cancel close-modal">İptal</button>
                </div>
            </form>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>