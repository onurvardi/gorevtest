<?php
// Hata gösterimini aç
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h2>Veritabanı Bağlantı Testi</h2>";

try {
    // Sizin bağlantı bilgilerinizle doğrudan test
    echo "<h3>1. Doğrudan PDO Bağlantı Testi:</h3>";
    $conn = new PDO(
        "mysql:host=localhost;dbname=aypi_gorev", 
        "aypi_gorev", 
        "gorev889965**"
    );
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "✅ Doğrudan bağlantı başarılı!<br>";

    // Veritabanı sınıfı ile test
    echo "<h3>2. Database Sınıfı Testi:</h3>";
    require_once 'config/database.php';
    $db = new Database();
    $conn2 = $db->getConnection();
    if($conn2) {
        echo "✅ Database sınıfı bağlantısı başarılı!<br>";
    }

    // Veritabanı içerik testi
    echo "<h3>3. Tablolar:</h3>";
    $tables = $conn->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "Mevcut tablolar:<br>";
    foreach($tables as $table) {
        echo "- " . $table . "<br>";
    }

} catch(PDOException $e) {
    echo "<h3>❌ HATA:</h3>";
    echo $e->getMessage() . "<br>";
    echo "<h4>Olası çözümler:</h4>";
    echo "1. Veritabanı adının doğru olduğundan emin olun (aypi_gorev)<br>";
    echo "2. Kullanıcı adı (aypi_gorev) ve şifrenin doğru olduğundan emin olun<br>";
    echo "3. MySQL servisinin çalıştığından emin olun<br>";
    echo "4. Veritabanının oluşturulduğundan emin olun<br>";
    echo "5. Hosting panelinizde veritabanı kullanıcısına yetki verildiğinden emin olun<br>";
}
?>